class FileLogger {
    log(message) {
        console.log(`${message}, logged in File`);
            ;
    }
}

module.exports = FileLogger;