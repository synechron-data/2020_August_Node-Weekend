exports.DBLFactory = {
    getLogger: function () {
        const DBLogger = require('./DBLogger');
        return new DBLogger();
    }
}

exports.FLFactory = {
    getLogger: function () {
        const FileLogger = require('./FileLogger');
        return new FileLogger();
    }
}