// require("./lib.js");

// const lib = require("./lib.js");
// console.log(lib);

// console.log(lib.firstname);
// console.log(lib.lastname);
// lib.log("Hi from Main Module");

// let e1 = new lib.Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const Employee = require("./lib.js").Employee;
// const { Employee } = require("./lib.js");

// let e1 = new Employee("Manish");
// console.log(e1.getName());
// e1.setName("Abhijeet");
// console.log(e1.getName());

// const lib1 = require("./lib.js");
// const lib2 = require("./lib.js");

// console.log(lib1 === lib2)

// ---------------------------------------------------------------------------

// const logger = require('./logger.js');
// const logger = require('./logger');

// ---------------------------------------------------------------------------

// const loggerService = require('./loggerService');
// loggerService.log("Hello from Main Module");

// ---------------------------------------------------------------------------

// const loggerSingle = require('./loggerSingle');

// let l1 = loggerSingle.getLogger();
// l1.log("Hi from Main Module");

// let l2 = loggerSingle.getLogger();
// l2.log("Hi from Main Module");

// console.log(l1 === l2);

// ---------------------------------------------------------------------------

const loggerFactory = require('./loggerFactory');

let dbLogger = loggerFactory.DBLFactory.getLogger();
let flLogger = loggerFactory.FLFactory.getLogger();

dbLogger.log("Hello from App Module");
flLogger.log("Hello from App Module");