const readline = require('readline');
const { resolve } = require('path');
// console.log(readline);

const rl = readline.createInterface({
    input: process.stdin,       // ReadStream
    output: process.stdout      // WriteStream    
});

// console.log(rl);

// rl.question("Enter a number", (input)=>{
//     console.log(`You entered ${input}`);
//     rl.close();
// });

// console.log("\n---------------- Last Line --------------- \n");
// rl.close();

// rl.question("Enter the first number: ", (input1) => {
//     rl.question("Enter the second number: ", (input2) => {
//         var sum = parseInt(input1) + parseInt(input2);
//         console.log(`Result is: ${sum}`);
//         rl.close();
//     });
// });

// Change the code using Promise API

// function enterNumberOne() {
//     return new Promise((resolve) => {
//         rl.question("Enter the first number: ", (input) => {
//             var num = parseInt(input);
//             resolve(num);
//         });
//     })
// }

// function enterNumberTwo(n1) {
//     return new Promise((resolve) => {
//         rl.question("Enter the second number: ", (input) => {
//             var num = parseInt(input);
//             resolve([n1, num]);
//         });
//     })
// }

// function add([n1, n2]) {
//     var sum = n1 + n2;
//     console.log(`Result is: ${sum}`);
//     rl.close();
// }

// enterNumberOne().then(enterNumberTwo).then(add);

// function enterNumberOne() {
//     return new Promise((resolve) => {
//         rl.question("Enter the first number: ", (input) => {
//             var num = parseInt(input);
//             resolve(num);
//             rl.close();
//         });
//     })
// }

// function enterNumberTwo() {
//     return new Promise((resolve) => {
//         rl.question("Enter the second number: ", (input) => {
//             var num = parseInt(input);
//             resolve([n1, num]);
//             rl.close();
//         });
//     })
// }

// Promise.all([enterNumberOne(), enterNumberTwo()]).then((data)=>{
//     console.log(data);
// });