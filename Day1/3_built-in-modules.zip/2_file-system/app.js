const fs = require('fs');

// fs.readFile('./file1.txt', 'utf-8', (err, data) => {
//     if (err)
//         console.log(err);
//     else
//         console.log(data);
// });

// try {
//     var data = fs.readFileSync('./file1.txt', 'utf-8');
//     console.log(data);
// } catch (err) {
//     console.log(err);
// }

// fs.writeFile('./file2.txt', 'Hello from Node App Module', 'utf-8', (err) => {
//     if (err)
//         console.log(err);
//     else
//         console.log("File Write Completed...");
// });

fs.appendFile('./file3.txt', 'Hello from Node App Module\n', 'utf-8', (err) => {
    if (err)
        console.log(err);
    else
        console.log("File Append Completed...");
});

console.log("Completed and waiting....");