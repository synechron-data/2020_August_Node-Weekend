var express = require('express');
var router = express.Router();

var users_api_ctrl = require('../controllers/users-api-controller');

router.get('/', users_api_ctrl.getUsers);

module.exports = router;
