var express = require('express');
var router = express.Router();

var users_ctrl = require('../controllers/users-controller');
var acc_ctrl = require('../controllers/account-controller');

router.use(acc_ctrl.isAuthenticated);

router.get('/', users_ctrl.index);

module.exports = router;
