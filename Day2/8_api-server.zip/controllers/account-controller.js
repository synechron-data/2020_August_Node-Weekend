exports.isAuthenticated = function (req, res, next) {
    if (req.isAuthenticated())
        next();
    else
        res.redirect('/account');
}

exports.login_get = function (req, res) {
    res.render('account/login', { title: 'Login', message: req.flash('loginMessage') });
}

exports.login_post = function (passport) {
    return passport.authenticate('local-login', {
        successRedirect: '/users',
        failureRedirect: '/account',
        failureFlash: true
    });
}