var express = require('express');
var router = express.Router();

var users_ctrl = require('../controllers/users-controller');

router.get('/', users_ctrl.index);

router.get('/details/:userid', users_ctrl.details);

router.get('/create', users_ctrl.create_get);

router.post('/create', users_ctrl.create_post);

router.get('/edit/:userid', users_ctrl.edit_get);

router.post('/edit/:userid', users_ctrl.edit_post);

router.get('/delete/:userid', users_ctrl.delete_get);

router.post('/delete/:userid', users_ctrl.delete_post);

module.exports = router;
