const da = require('../data-access');

exports.getUsers = function (req, res) {
    console.log("Get Users Called...");
    da.getAllUsers().then((result) => {
        console.log(result);
        res.json({ data: result, message: "Success, Getting Users" });
    }, (eMsg) => {
        res.json({ data: [], message: "Error, Getting Users" });
    })
};